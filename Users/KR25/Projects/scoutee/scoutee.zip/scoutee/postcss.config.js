{
  "plugins": {
    "tailwindcss": {},
    "autoprefixer": {}
  }
}
