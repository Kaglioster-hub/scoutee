# 🦊 Scoutee — Survival Companion Europe+World

Super-app gratuita per viaggiatori: servizi locali, SOS, AI.  
- Mobility (Uber, Bolt, Enjoy, e-scooters…)  
- Connectivity (Airalo, Holafly, Nomad)  
- Fintech (Revolut, Wise, N26)  
- Food (Glovo, Wolt, Deliveroo, UberEats)  
- Tours (GetYourGuide, Klook, TheFork)

Tech: Next.js 14, Tailwind, SEO, PWA, i18n-ready, CI/CD.
