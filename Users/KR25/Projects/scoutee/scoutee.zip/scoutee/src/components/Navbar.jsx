export default function Navbar(){return(<nav className='p-4 shadow-md bg-white dark:bg-gray-900 sticky top-0 z-50'>🦊 Scoutee</nav>)}
