import {useState} from 'react';
export default function ChatBotAI(){
  const [m,setM]=useState([{from:'bot',text:'Hi! I am Scoutee AI'}]); const [i,setI]=useState('');
  const send=async()=>{ if(!i.trim())return; setM(v=>[...v,{from:'user',text:i}]);
    try{ const r=await fetch('/api/chat',{method:'POST',body:JSON.stringify({message:i})});
      const d=await r.json(); setM(v=>[...v,{from:'bot',text:d.reply}]); }
    catch{ setM(v=>[...v,{from:'bot',text:'(offline) Try SOS or Uber'}]); }
    setI(''); };
  return(<div className='fixed bottom-20 right-4 w-80 bg-white dark:bg-gray-900 border rounded-xl shadow-xl'>
    <div className='p-3 h-56 overflow-y-auto text-sm space-y-1'>{m.map((x,k)=>
      <div key={k} className={x.from==='bot'?'text-primary font-semibold':'text-gray-800 dark:text-gray-100'}>{x.text}</div>)}
    </div>
    <div className='flex border-t'>
      <input value={i} onChange={e=>setI(e.target.value)} className='flex-1 p-2 text-sm bg-transparent outline-none'/>
      <button onClick={send} className='px-3 bg-primary text-white rounded-r-xl'>▶</button>
    </div></div>);
}
