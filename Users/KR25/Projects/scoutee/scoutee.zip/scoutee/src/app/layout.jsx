import '@/styles/globals.css';
import SEO from '@/lib/SEO';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function RootLayout({children}){
  return (
    <html lang="en">
      <body className="bg-comfort-light dark:bg-comfort-dark text-gray-900 dark:text-gray-100">
        <SEO/>
        <Navbar/>
        <main className="min-h-screen">{children}</main>
        <Footer/>
      </body>
    </html>
  );
}
